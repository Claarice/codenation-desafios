package dev.codenation.modulo08;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Modulo08Application {

	public static void main(String[] args) {
		SpringApplication.run(Modulo08Application.class, args);
	}

}
