package dev.codenation.modulo08;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Modulo08ApplicationTests {

	@Test
	void contextLoads() {
	}

}
